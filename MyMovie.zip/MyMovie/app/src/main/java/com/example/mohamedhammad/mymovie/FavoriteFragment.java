package com.example.mohamedhammad.mymovie;

import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mohamedhammad.mymovie.Adapters.FavoriteAdapter;
import com.example.mohamedhammad.mymovie.filmy.FilmyData;
import com.example.mohamedhammad.mymovie.filmy.FilmyHelper;
import com.example.mohamedhammad.mymovie.filmy.FilmySchema;

import java.util.ArrayList;
import java.util.List;

public class FavoriteFragment extends Fragment {

    private RecyclerView recyclerView;
    private FavoriteAdapter adapter;
    private List<FilmyData> albumList;
    FilmyHelper myHelper;
    SQLiteDatabase dB;
    public FavoriteFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        albumList = new ArrayList<>();
        myHelper = new FilmyHelper(getActivity() );
        dB = myHelper.getReadableDatabase();
        adapter = new FavoriteAdapter(getActivity(), albumList);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(10), true));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        loadFromDB();
    }

    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view);
            int column = position % spanCount;

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount;
                outRect.right = (column + 1) * spacing / spanCount;

                if (position < spanCount) {
                    outRect.top = spacing;
                }
                outRect.bottom = spacing;
            } else {
                outRect.left = column * spacing / spanCount;
                outRect.right = spacing - (column + 1) * spacing / spanCount;
                if (position >= spanCount) {
                    outRect.top = spacing;
                }
            }
        }
    }
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    private void loadFromDB() {
        albumList.clear();

        String s[]={FilmySchema.COL_MOVIE_ID , FilmySchema.COL_TITLE,
                FilmySchema.COL_DATE , FilmySchema.COL_RATE ,
                FilmySchema.COL_OVERVIEW , FilmySchema.COL_REVIEWS,
                FilmySchema.COL_TRAILERS ,    FilmySchema.COL_TRAILERS_KEY,  FilmySchema.COL_POSTER };
        Cursor c = dB.query(false, FilmySchema.TABLE_NAME ,s , null , null , null,null,null , null);
        if(c.moveToNext()){


            do{
                int idIndex = c.getColumnIndex(FilmySchema.COL_MOVIE_ID);
                int titleIndex = c.getColumnIndex(FilmySchema.COL_TITLE);
                int dateIndex = c.getColumnIndex( FilmySchema.COL_DATE);
                int rateIndex = c.getColumnIndex(FilmySchema.COL_RATE);
                int overviewIndex = c.getColumnIndex( FilmySchema.COL_OVERVIEW );
                int reviewsIndex = c.getColumnIndex(FilmySchema.COL_REVIEWS);
                int trialInex = c.getColumnIndex( FilmySchema.COL_TRAILERS);
                int triKeyIndex = c.getColumnIndex(   FilmySchema.COL_TRAILERS_KEY);
                int posterIndex = c.getColumnIndex(FilmySchema.COL_POSTER);


                String movID = String.valueOf(c.getInt(idIndex));
                String title = c.getString(titleIndex);
                String date = c.getString(dateIndex);
                double rate = c.getDouble(rateIndex);
                String overview = c.getString(overviewIndex);
                String reviews = c.getString(reviewsIndex);
                String trials = c.getString(trialInex);
                String trial_name = c.getString(triKeyIndex);
                byte poster[] = c.getBlob(posterIndex);

                Bitmap posterImage = getImage(poster);
                FilmyData myFav = new FilmyData(movID ,rate , title , date , overview , reviews , trials, trial_name, posterImage);
                albumList.add(myFav);
            }while (c.moveToNext());
        }
        adapter = new FavoriteAdapter(getActivity(),albumList);
        recyclerView.setAdapter(adapter);

    }
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }
}
