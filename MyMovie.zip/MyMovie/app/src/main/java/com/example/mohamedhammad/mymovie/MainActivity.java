package com.example.mohamedhammad.mymovie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.example.mohamedhammad.mymovie.filmy.FilmyData;

public class MainActivity extends AppCompatActivity implements MainActivityFragment.myInterface {

    boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(findViewById(R.id.fram_detail)==null){
            flag=false;
        }else{
            flag =true;
        }
    }

    @Override
    public void Call(FilmyData film) {
        if(flag){
            DetailsFragment detailsFragment = DetailsFragment.getInstanceFrag(film);
            getSupportFragmentManager().beginTransaction().replace(R.id.fram_detail,detailsFragment).commit();
        }else{
            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
            intent.putExtra("selected",film);
            startActivity(intent);

        }
    }
}
