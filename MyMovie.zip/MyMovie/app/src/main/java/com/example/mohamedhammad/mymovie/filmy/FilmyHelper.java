package com.example.mohamedhammad.mymovie.filmy;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class FilmyHelper extends SQLiteOpenHelper {
    public FilmyHelper(Context context){
        super(context, FilmySchema.DB_NAME, null, FilmySchema.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table "+ FilmySchema.TABLE_NAME+" ( "+ FilmySchema.COL_ID+" integer primary key autoincrement not null , "+
                FilmySchema.COL_MOVIE_ID+" integer not null , "+
                FilmySchema.COL_RATE+" real not null , "+
                FilmySchema.COL_DATE+" text not null , "+
                FilmySchema.COL_TITLE+" text not null , "+
                FilmySchema.COL_OVERVIEW+" text not null , "+
                FilmySchema.COL_REVIEWS+" text not null , "+
                FilmySchema.COL_TRAILERS+" text not null , "+
                FilmySchema.COL_TRAILERS_KEY+" text not null ,"+
                FilmySchema.COL_POSTER+" blob not null ) ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
