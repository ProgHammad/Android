package com.example.mohamedhammad.mymovie.filmy;

public class FilmySchema {
    public static final String DB_NAME = "movie_fav";
    public static final String TABLE_NAME = "fav";
    public static final String COL_ID = "id";
    public static final String COL_MOVIE_ID = "mov_id";
    public static final String COL_TITLE = "title";
    public static final String COL_RATE = "rate";
    public static final String COL_OVERVIEW = "overview";
    public static final String COL_DATE = "date";
    public static final String COL_REVIEWS = "reviews";
    public static final String COL_TRAILERS = "trailers";
    public static final String COL_TRAILERS_KEY = "trailers_keys";
    public static final String COL_POSTER = "poster";
    public static final int DB_VERSION = 1;

}
