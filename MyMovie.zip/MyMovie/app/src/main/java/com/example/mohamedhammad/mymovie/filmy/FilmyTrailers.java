package com.example.mohamedhammad.mymovie.filmy;

import java.util.ArrayList;

public class FilmyTrailers {
    private ArrayList<String> trailKey;
    private ArrayList<String> trailName;

    public FilmyTrailers(ArrayList<String> trailKey, ArrayList<String> trailName){
        this.setTrailKey(trailKey);
        this.setTrailName(trailName);
    }

    public void setTrailName(ArrayList<String> trailName) { this.trailName = trailName; }
    public void setTrailKey(ArrayList<String> trailKey) { this.trailKey = trailKey; }
    public ArrayList<String> getTrailName() { return trailName; }
    public ArrayList<String> getTrailKey() { return trailKey; }
}
