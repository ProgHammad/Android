package com.example.mohamedhammad.mymovie;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.example.mohamedhammad.mymovie.filmy.FilmyData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivityFragment extends Fragment {

    private RecyclerView recyclerView;
    private AlbumsAdapter adapter;
    private List<FilmyData> albumList;
    private ProgressDialog loading;
    private SharedPreferences sharedPreferences;
    HttpURLConnection urlConnection = null;
     private Dialog dialog;
    private RadioGroup rG;
    private String sortBy;

    public MainActivityFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.main_menu, menu);
    }
    MainActivity m=new MainActivity();

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_sorting) {
            showRadioSorting();
            return true;
        }
        if (id == R.id.action_fav) {
            startActivity(new Intent(getActivity(), Favorite.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        albumList = new ArrayList<>();
        adapter = new AlbumsAdapter(getActivity(), albumList);
        sharedPreferences = getActivity().getSharedPreferences("myData", Context.MODE_PRIVATE);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(10), true));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
        return view;
    }


    public  void getStart() {
            FetchMovieData fetchMovieData = new FetchMovieData();
            fetchMovieData.execute("");
    }

    @Override
    public void onStart() {
        super.onStart();
        getStart();
    }

    private void showRadioSorting() {
        dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.sort_activity);
        rG = (RadioGroup) dialog.findViewById(R.id.radio_group);

        RadioButton topRating = (RadioButton) dialog.findViewById(R.id.top_rating);
        RadioButton popularity = (RadioButton) dialog.findViewById(R.id.popularity);
        if (sharedPreferences.getBoolean("is_Pop", false))
            popularity.setChecked(true);
        else
            topRating.setChecked(true);

        topRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sort();
            }
        });


        popularity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              sort();
            }
        });
        dialog.show();

    }

    public void sort(){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        int selectedID = rG.getCheckedRadioButtonId();
        if (selectedID == R.id.popularity)
            editor.putBoolean("is_Pop", true);
        else
            editor.putBoolean("is_Pop", false);



        boolean sortpop = sharedPreferences.getBoolean("is_Pop", false);
        if (sortpop) {
            sortBy = "top_rated";
        }else {
            sortBy = "popularity.desc";
        }
        editor.putString("sort_by", sortBy);

        editor.commit();
        dialog.dismiss();
        getStart();
    }

    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view);
            int column = position % spanCount;

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount;
                outRect.right = (column + 1) * spacing / spanCount;

                if (position < spanCount) {
                    outRect.top = spacing;
                }
                outRect.bottom = spacing;
            } else {
                outRect.left = column * spacing / spanCount;
                outRect.right = spacing - (column + 1) * spacing / spanCount;
                if (position >= spanCount) {
                    outRect.top = spacing;
                }
            }
        }
    }

    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }


    public class FetchMovieData extends AsyncTask<String, Void, List<FilmyData>> {

        private final String LOG_TAG = FetchMovieData.class.getSimpleName();

        @Override
        protected void onPreExecute() {
            try {
                loading = ProgressDialog.show(getActivity(), "My Movie", "Please wait...", true, true);
            } catch (Exception e) {

            }

            super.onPreExecute();
        }


        @Override
        protected List<FilmyData> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }

            BufferedReader reader = null;
            String sortBy = sharedPreferences.getString("sort_by", "top_rated");
            String movieDBJsonStr = null;

            try {
                URL url = new URL("http://api.themoviedb.org/3/discover/movie?sort_by=" + sortBy + "&api_key=ce72446ea6823edc7bb9cd3d15bbd63e");
                Log.i("URL", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                movieDBJsonStr = buffer.toString();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);

                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            try {
                return getMovieDataFromJson(movieDBJsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }


            return null;
        }

        private List<FilmyData> getMovieDataFromJson(String movieDBJsonStr) throws JSONException {
            final String RESULT = "results";
            final String POSTER_PATH = "poster_path";
            final String OVERVIEW = "overview";
            final String TITLE = "title";
            final String DATE = "release_date";
            final String RATE = "vote_count";
            final String ID = "id";

            JSONObject movieJson = new JSONObject(movieDBJsonStr);
            JSONArray movieArray = movieJson.getJSONArray(RESULT);
            List<FilmyData> cinemaList = new ArrayList<>();
            for (int i = 0; i < movieArray.length(); i++) {

                String poster_path;
                String overview;
                String title;
                String date;
                String movID;
                double rate;

                JSONObject singleMovie = movieArray.getJSONObject(i);

                poster_path = singleMovie.getString(POSTER_PATH);
                overview = singleMovie.getString(OVERVIEW);
                title = singleMovie.getString(TITLE);
                date = singleMovie.getString(DATE);
                rate = Double.parseDouble(singleMovie.getString(RATE));
                movID = singleMovie.getString(ID);
                cinemaList.add(new FilmyData(movID, title, overview, poster_path, date, rate));
            }
            return cinemaList;

        }


        protected void onPostExecute(List<FilmyData> albumList) {
            adapter = new AlbumsAdapter(getActivity(), albumList);
            recyclerView.setAdapter(adapter);
            loading.dismiss();

        }

    }

    public class AlbumsAdapter extends RecyclerView.Adapter<AlbumsAdapter.MyViewHolder> {

        private Context myContext;
        private List<FilmyData> albumList;


        public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView title;
            public ImageView thumbnail;

            public MyViewHolder(View view) {
                super(view);
                title = (TextView) view.findViewById(R.id.title);
                thumbnail = (ImageView) view.findViewById(R.id.thumbnail);
            }
        }

        public AlbumsAdapter(Context myContext, List<FilmyData> albumList) {
            this.myContext = myContext;
            this.albumList = albumList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, int position) {
            final FilmyData film = albumList.get(position);
            holder.title.setText(film.getTitle());
            Picasso.with(myContext).load("http://image.tmdb.org/t/p/w185/" + film.getPosterLink()).into(holder.thumbnail);
            holder.thumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((MainActivity) myContext).Call(film);
                }
            });
        }

        @Override
        public int getItemCount() {

            return albumList.size();
        }
    }
        public interface myInterface {

            void Call(FilmyData film);
        }
    }