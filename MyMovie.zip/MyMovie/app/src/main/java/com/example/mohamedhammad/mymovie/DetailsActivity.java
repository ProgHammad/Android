package com.example.mohamedhammad.mymovie;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.example.mohamedhammad.mymovie.filmy.FilmyData;

public class DetailsActivity extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

     FilmyData film = getIntent().getExtras().getParcelable("selected");
        DetailsFragment detailsFragment = DetailsFragment.getInstanceFrag(film);
        getSupportFragmentManager().beginTransaction().replace(R.id.fram_detail,detailsFragment).commit();
    }
}

