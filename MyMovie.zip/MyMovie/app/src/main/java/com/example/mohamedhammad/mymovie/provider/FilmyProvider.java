package com.example.mohamedhammad.mymovie.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.Nullable;

import com.example.mohamedhammad.mymovie.filmy.FilmyHelper;
import com.example.mohamedhammad.mymovie.filmy.FilmySchema;

public class FilmyProvider extends ContentProvider {
    private static final String author = "com.example.mohamedhammad.mymovie.FilmyProvider";
    private static final int CHOICE_TABLE = 1;
    private UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    FilmyHelper myHelper ;
    SQLiteDatabase db ;

    @Override
    public boolean onCreate() {
        uriMatcher.addURI(author , FilmySchema.TABLE_NAME , CHOICE_TABLE );
        return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] strings, String s, String[] strings1, String s1) {
        myHelper = new FilmyHelper(getContext());
        db = myHelper.getReadableDatabase();
        int result =  uriMatcher.match(uri);
        if(result == CHOICE_TABLE){
            return   db.query(FilmySchema.TABLE_NAME  , strings , s ,strings1 , null , null,s1 );
        }


        return null;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(Uri uri, String s, String[] strings) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String s, String[] strings) {
        return 0;
    }
}
