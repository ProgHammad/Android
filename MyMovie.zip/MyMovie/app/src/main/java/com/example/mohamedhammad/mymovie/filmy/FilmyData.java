package com.example.mohamedhammad.mymovie.filmy;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

public class FilmyData implements Parcelable {
    private String mov_id;
    private double rate;
    private String title ;
    private String poster_path ;
    private String date ;
    private String overview ;
    private String reviews;
    private String trialers;
    private String trialers_name;
    private Bitmap poster ;
    public FilmyData(String movID, String title, String overview, String poster_path, String Date, double Rate){
        this.setTitle(title);
        this.setOverview(overview);
        this.setPosterLink(poster_path);
        this.setDate(Date);
        this.setRate(Rate);
        this.setMov_id(movID);
    }
    public FilmyData(String mov_id, double rate, String title, String date, String overview, String reviews, String trialers, String trialers_name, Bitmap poster) {
        this.setMov_id(mov_id);
        this.setRate(rate);
        this.setTitle(title);
        this.setDate(date);
        this.setOverview(overview);
        this.setReviews(reviews);
        this.setTrialers(trialers);
        this.setPoster(poster);
        this.setTrialers_name(trialers_name);
    }

    protected FilmyData(Parcel in) {
        mov_id = in.readString();
        rate = in.readDouble();
        title = in.readString();
        poster_path = in.readString();
        date = in.readString();
        overview = in.readString();
        reviews = in.readString();
        trialers = in.readString();
        trialers_name = in.readString();
        poster = in.readParcelable(Bitmap.class.getClassLoader());
    }

    public static final Creator<FilmyData> CREATOR = new Creator<FilmyData>() {
        @Override
        public FilmyData createFromParcel(Parcel in) {
            return new FilmyData(in);
        }

        @Override
        public FilmyData[] newArray(int size) {
            return new FilmyData[size];
        }
    };

    public String getMov_id() {
        return mov_id;
    }

    public void setMov_id(String mov_id) {
        this.mov_id = mov_id;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getReviews() {
        return reviews;
    }

    public void setReviews(String reviews) {
        this.reviews = reviews;
    }

    public String getTrialers() {
        return trialers;
    }

    public void setTrialers(String trialers) {
        this.trialers = trialers;
    }

    public String getTrialers_name() {
        return trialers_name;
    }

    public void setTrialers_name(String trialers_name) {
        this.trialers_name = trialers_name;
    }

    public Bitmap getPoster() {
        return poster;
    }

    public void setPoster(Bitmap poster) {
        this.poster = poster;
    }

    public String getPosterLink() {
        return poster_path;
    }

    public void setPosterLink(String posterLink) {
        this.poster_path = posterLink;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mov_id);
        parcel.writeDouble(rate);
        parcel.writeString(title);
        parcel.writeString(poster_path);
        parcel.writeString(date);
        parcel.writeString(overview);
        parcel.writeString(reviews);
        parcel.writeString(trialers);
        parcel.writeString(trialers_name);
        parcel.writeParcelable(poster, i);
    }
}
