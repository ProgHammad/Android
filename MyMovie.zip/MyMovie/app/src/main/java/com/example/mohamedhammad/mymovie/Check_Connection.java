package com.example.mohamedhammad.mymovie;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Check_Connection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check__connection);
        Thread background = new Thread() {
            public void run() {
                    Check_Connection.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(isOnLine()){
                                Intent i=new Intent(getBaseContext(),MainActivity.class);
                                startActivity(i);
                            }else{
                                Toast.makeText(getBaseContext(), "No Internet Access ○○○", Toast.LENGTH_LONG).show();
                                Intent i=new Intent(getBaseContext(),Favorite.class);
                                startActivity(i);

                            }
                        }
                    });
                }

        };

        // start thread
        background.start();

    }
    public  Boolean  isOnLine(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
